let heading =document.getElementById("mainHeading");
let textNode = document.createTextNode(" - Saira Rehan, 55222");

heading.append(textNode);

console.log(mainHeading);