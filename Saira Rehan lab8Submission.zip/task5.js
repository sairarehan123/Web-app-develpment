let para = document.querySelector(".myPara");
para.classList.add("newStyle");
