const box = document.getElementById("hoverBox");

box.onmouseover = function() {
  box.style.backgroundColor = "orange";
  box.textContent = "You are beautiful :)";
}

box.onmouseout = function() {
  box.style.backgroundColor = "lightblue";
  box.textContent = "Hover over me!";
}
